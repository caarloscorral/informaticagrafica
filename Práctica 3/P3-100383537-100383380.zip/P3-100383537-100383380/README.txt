- Al abrir el fichero .tgd por primera vez dara error porque no encuentra un objeto. Dicho objeto esta en el fichero Pine01_2-tgo que se encuentra
en la misma carpeta. Será necesario volver a señalar que el objeto esta linkeado a ese fichero. No encontramos manera de solucionarlo.

- La imagen .tif se ha renderizado con una resolucion de 1280x900, con un aliasing de 4 y 0.6 de microparticulas. Es lo maximo permitido en
la version gratuita.

- El objeto del arbol se ha descargado de la pagina oficial de terragen, de un pack de plantas.