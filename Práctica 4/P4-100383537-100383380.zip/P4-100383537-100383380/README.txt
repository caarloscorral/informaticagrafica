- Hemos ido bastante justos de tiempo para realizar la práctica por otras asignaturas.

- No ha sido posible encontrar un arbol/arbusto que se ajustara a la imagen, todos eran bastante diferentes.

- De la misma forma ha ocurrido con las piedras.
